const header = document.getElementById("mainHeader");
  const logo = document.getElementById("logo");

  window.addEventListener("scroll", () => {
    if (window.scrollY > 50) {
      header.classList.add("scrolled");
      // logo.classList.add("logo-hidden");
    } else {
      header.classList.remove("scrolled");
      logo.classList.remove("logo-hidden");
    }
  });

